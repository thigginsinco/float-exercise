# CSS Float Exercises

Each of the four exercises have TODO markers throughout their code.

Your assignment is to fix each of these TODOs.

### Exercise One:
Left Floating an Image

### Exercise Two:
Clearing and Scrolling

### Exercise Three:
Ordering of Floats

### Exercise Three:
Floating Multiple Images
